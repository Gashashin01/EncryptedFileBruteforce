﻿#include <string>
#include <vector>
#include <fstream>
#include <exception>
#include <iostream>
#include <algorithm>
#include <chrono>
#include <thread>
#include <mutex>

#include <openssl/evp.h>
#include <openssl/aes.h>
#include <openssl/sha.h>
#include "Decrypt.h"
#include "Bruteforce.h"

#define BRUT_NUMBERS       (1<<0)
#define BRUT_ENG_LOWERCASE (1<<1)

std::string g_foundPass;
std::vector<std::string> g_passwords;
std::mutex decryptMutex;
int g_i = 0;

int PasswordChecking(Decrypt decrypt) {
    //int i = 0;
    while (true) {
        if (g_i != g_passwords.size() - 1) {
            decryptMutex.lock();
            //std::cout << g_passwords[g_i] << std::endl;
            bool stat = decrypt.DecryptMain(g_passwords[g_i]);
            g_i++;
            if (stat) {
                decryptMutex.unlock();
                g_foundPass = g_passwords[g_i-1];
                return 0;
            }
            else {
                decryptMutex.unlock();
            }
        }
        else {
            continue;
        }
    }
}

Bruteforce::Bruteforce(Decrypt decrypt) :
    m_decrypt(decrypt)
    //m_passwords(passwords)
{}

void Bruteforce::SetAlphabet(int letterSet) {
    std::string letters = "";
    if (letterSet & BRUT_NUMBERS) { 
        letters += "0123456789"; 
    }
    if (letterSet & BRUT_ENG_LOWERCASE) { 
        letters += "abcdefghijklmnopqrstuvwxyz"; 
    }

    for (size_t i = 0; i < letters.size(); i++) {
        m_alphabet.push_back(letters[i]);
    }
}

int Bruteforce::BruteforcePassword(int brutforceSize, std::vector<unsigned char> cipherText, std::vector<unsigned char> cipherHash) {
    std::vector<int> password(brutforceSize); 
    for (size_t i = 0; i < password.size(); i++) {
        password[i] = 0;
    }
    
    std::string lastAviablePass = std::string(password.size(), m_alphabet.back());

    bool needBreakLoop = false;
    while (!needBreakLoop) {
        int i = 0;
        for (size_t letter = 0; letter < m_alphabet.size(); letter++) {
            password[0] = letter;
            std::string pass = std::string();
            for (size_t i = 0; i < password.size(); i++) {
                pass.push_back(m_alphabet[password[i]]);
            }
            decryptMutex.lock();
            g_passwords.push_back(pass);
            decryptMutex.unlock();
            if (!g_foundPass.empty()) {
                return 0;
            }
            /*if (m_decrypt.DecryptMain(pass)) {
                return pass;
            }*/
            if (pass == lastAviablePass) {
                needBreakLoop = true;
            }
            
        }
        for (size_t i = 1; i < password.size(); i++) {
            password[i]++;
            if (password[i] == m_alphabet.size()) {
                password[i] = 0;
            }
            else {
                break;
            }
        }
    }
    return 0;
}

int Bruteforce::BruteforceMain() {
    int alphabet = BRUT_NUMBERS | BRUT_ENG_LOWERCASE;

    alphabet = BRUT_NUMBERS | BRUT_ENG_LOWERCASE;
    SetAlphabet(alphabet);
    
    int brutedpassSize = 0;
    auto begin = std::chrono::high_resolution_clock::now();
    
    std::thread tr1(PasswordChecking, m_decrypt);
    std::thread tr2(PasswordChecking, m_decrypt);
    std::string brutedpass;
    while (brutedpassSize != 5) {
        brutedpassSize++;
        BruteforcePassword(brutedpassSize, m_decrypt.GetCipherText(), m_decrypt.GetCipherHash());
    }
    tr1.join();
    tr2.join();
    if (!g_foundPass.empty()) {
        //оп, пароль найден, выводим
        auto end = std::chrono::high_resolution_clock::now();
        std::cout << "----------------------" << std::endl;
        std::cout << "Your password: " << g_foundPass << std::endl;
        std::cout << "Bruteforce took: ";
        std::cout << std::chrono::duration_cast<std::chrono::seconds>(end - begin).count() << " second(s)" << std::endl;
        return 0;
    }
    return 0;
}


